# Assignment5
Clustering &amp; PCA

In the attached files you will find instructions for assignment 5. Please **fork** this repository to your own Github account and then clone it in RStudio.

Good luck!

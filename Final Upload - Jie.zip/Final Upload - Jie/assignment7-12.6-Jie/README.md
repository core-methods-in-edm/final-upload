# Assignment 7
Diagnostic metrics

In the following assignment you will be looking at data from an one level of an online geography tutoring system used by 5th grade students. Your task will be to build some classification trees and then generate a diagnostic metrics about those trees.

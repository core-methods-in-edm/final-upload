# Assignment 2
Social Network Analysis

Please fork and clone this repo. The instructions to Assignment 2 are in the Assignment 2.rmd file. Once you have finished, commit, push and pull your assignment back to the main branch.

Good luck!
